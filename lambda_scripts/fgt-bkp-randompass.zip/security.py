import secrets

def password_generator(length):
    letters = 'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM'
    digits = '1234567890'
    special_chars = '-!@#$&*_'

    password = ''
    pwd_len = length

    count = 0
    while count < pwd_len:

        if count < pwd_len:
            password += secrets.choice(letters)
            count += 1
        if count < pwd_len:
            password += secrets.choice(digits)
            count += 1
        if count < pwd_len:
            password += secrets.choice(special_chars)
            count += 1

    return password